
brew install ta-lib

pip3 install ta-lib
